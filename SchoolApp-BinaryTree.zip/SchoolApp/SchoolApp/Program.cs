﻿using LoggingService;
using SchoolDomain;
using SchoolService;
using System;
using System.Collections.Generic;
using System.Diagnostics;

namespace SchoolApp
{
    class Program
    {
        static List<Guid> instructorIds;
        static int maxInstructors = 1200;
        static List<Guid> courseIds;
        static int maxCourses = 1000000;
        static List<Guid> studentIds;
        static int maxStudents = 50000;
        static readonly string thingsToDo = @"
-------------------------------
1. Load Persisted Data
2. Save Persisted Data
3. Recreate Persisted Data
4. Sort Students
5. Skip and Fetch Students
6. Skip and Fetch Instructors
7. Skip and Fetch Courses
8. Search for a Student by Name
9. Search for a Course by Name
-------------------------------
Q. Quit

What's your choice ";

        static void Main(string[] args)
        {
            while (true)
            {
                Console.Clear();
                Console.Write(thingsToDo);
                var choice = Console.ReadLine();
                switch (choice.ToUpper())
                {
                    case "1":
                        var loadMsg = LoadData();
                        Console.WriteLine(loadMsg);
                        break;
                    case "2":
                        var saveMsg = SaveData();
                        Console.WriteLine(saveMsg);
                        break;
                    case "3":
                        CreateLotsOfData();
                        Console.WriteLine("Data created.");
                        break;
                    case "4":
                        SortStudents();
                        break;
                    case "5":
                        Console.Write("Enter skip: ");
                        var skipStudents = Convert.ToInt32(Console.ReadLine());
                        Console.Write("Enter count: ");
                        var countStudents = Convert.ToInt32(Console.ReadLine());
                        SkipAndFetchStudent(skipStudents, countStudents);
                        break;
                    case "6":
                        Console.Write("Enter skip: ");
                        var skipInstructors = Convert.ToInt32(Console.ReadLine());
                        Console.Write("Enter count: ");
                        var countInstructors = Convert.ToInt32(Console.ReadLine());
                        SkipAndFetchInstructor(skipInstructors, countInstructors);
                        break;
                    case "7":
                        Console.Write("Enter skip: ");
                        var skipCourses = Convert.ToInt32(Console.ReadLine());
                        Console.Write("Enter count: ");
                        var countCourses = Convert.ToInt32(Console.ReadLine());
                        SkipAndFetchCourse(skipCourses, countCourses);
                        break;
                    case "8":
                        Console.Write("Enter the student's name you are looking for: ");
                        var name = Console.ReadLine();
                        SearchStudentName(name);
                        break;
                    case "9":
                        Console.Write("Enter the course name you are looking for: ");
                        var courseName = Console.ReadLine();
                        SearchCourseName(courseName);
                        break;
                    case "Q":
                        Console.Clear();
                        Console.WriteLine("Thank you, good bye");
                        return;
                    default:
                        Console.Write($"Your choice of {choice} is unknown.");
                        break;
                }
                Console.Write("Press ENTER to continue>>> ");
                Console.ReadLine();
            }
        }

        static void SearchStudentName(string name)
        {
            var service = new Service();
            var student = (Student)service.Controller("SearchStudent", new string[] { name });
            if (student == null) Console.WriteLine("Student not found");
            else
            {
                Console.WriteLine($@"
Found Student
==================================
Id: {student.Id}
Name: {student.Name}
GPA: {student.Gpa}");
            }
        }

        static void SearchCourseName(string name)
        {
            var service = new Service();
            var course = (Course)service.Controller("SearchCourse", new string[] { name });
            if (course == null) Console.WriteLine("Course not found");
            else
            {
                Console.WriteLine($@"
Found Course
==================================
Id: {course.Id}
Name: {course.CourseName}
Credit Hours: {course.CreditHours}");
            }
        }

        static void SortStudents()
        {
            var service = new Service();
            service.Controller("SortStudents");
        }

        static void SkipAndFetchStudent(int skip, int count)
        {
            var service = new Service();
            var students = (Student[])service.Controller("SkipAndFetch", new string[] { "student", skip.ToString(), count.ToString() });
            Console.WriteLine("Id                                        Name           GPA");
            Console.WriteLine("------------------------------------------------------------");
            foreach (var student in students)
            {
                Console.WriteLine($"{student.Id}      {student.Name}        {student.Gpa}");
            }
        }

        static void SkipAndFetchInstructor(int skip, int count)
        {
            var service = new Service();
            var instructors = (Instructor[])service.Controller("SkipAndFetch", new string[] { "instructor", skip.ToString(), count.ToString() });
            Console.WriteLine("Id                                        Name");
            Console.WriteLine("----------------------------------------------");
            foreach (var instructor in instructors)
            {
                Console.WriteLine($"{instructor.Id}      {instructor.Name}");
            }
        }

        static void SkipAndFetchCourse(int skip, int count)
        {
            var service = new Service();
            var courses = (Course[])service.Controller("SkipAndFetch", new string[] { "course", skip.ToString(), count.ToString() });
            Console.WriteLine("Id                                        Name           Credit Hours");
            Console.WriteLine("---------------------------------------------------------------------");
            foreach (var course in courses)
            {
                Console.WriteLine($"{course.Id}      {course.CourseName}        {course.CreditHours}");
            }
        }

        static string LoadData()
        {
            var service = new Service();
            return (string)service.Controller("LoadData");
        }

        static string SaveData()
        {
            var service = new Service();
            return (string)service.Controller("PersistData");
        }

        static string GetRandomWord(int length)
        {
            var rand = new Random();
            var word = string.Empty;
            char offset = 'a';
            const int lettersOffset = 26; // A...Z or a..z: length = 26  

            for (var i=0; i<length; i++)
            {
                word += (char)rand.Next(offset, lettersOffset+offset);
                if (i == 0) word = word.ToUpper();
            }

            return word;
        }

        static void CreateLotsOfData()
        {
            instructorIds = new List<Guid>();
            courseIds = new List<Guid>();
            studentIds = new List<Guid>();

            var service = new Service();

            for (var i = 1; i <= maxInstructors; i++)
            {
                var id = (Guid)service.Controller("CreateInstructor", new string[] { GetRandomWord(7) });
                instructorIds.Add(id);
            }

            var sw = new Stopwatch();
            sw.Start();
            for (var i = 1; i <= maxCourses; i++)
            {
                var id = (Guid)service.Controller("CreateCourse", new string[] { GetRandomWord(7), "3" });
                courseIds.Add(id);
            }
            sw.Stop();
            Logger.Info($"Created and Sorted {courseIds.Count} courses in {sw.ElapsedMilliseconds} milli-seconds.");

            for (var i = 1; i <= maxStudents; i++)
            {
                var id = (Guid)service.Controller("CreateStudent", new string[] { GetRandomWord(7), "0" });
                studentIds.Add(id);
            }
            var loadInfo = $@"Loaded:
Students: {studentIds.Count}
Courses: {courseIds.Count}
Instructors: {instructorIds.Count}";
            Logger.Info(loadInfo);
        }

    }
}
