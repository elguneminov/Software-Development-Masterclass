﻿using System;

namespace SchoolData
{
    public class Data
    {
    }
}
