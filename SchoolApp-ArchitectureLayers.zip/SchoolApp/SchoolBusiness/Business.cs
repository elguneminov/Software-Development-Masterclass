﻿using System;

namespace SchoolBusiness
{
    public class Business
    {
    }
}
