﻿using System;

namespace SchoolService
{
    public class Service
    {
    }
}
