﻿using System;

namespace SchoolDomain
{
    public class Domain
    {
    }
}
