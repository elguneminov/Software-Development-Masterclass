﻿using System;

namespace Triangles
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("What size triangle would you like? (3-20): ");
            int size = 0;
            if (!int.TryParse(Console.ReadLine(), out size))
            {
                Console.WriteLine("You gotta enter a number!");
            }
            else
            {
                if (size < 3 || size > 20)
                {
                    Console.WriteLine("Your triangle size must be between 3 and 20!");
                }
                else
                {
                    for (int i=0; i<size; i++)
                    {
                        for (int j=0; j<i; j++)
                        {
                            Console.Write("*");
                        }
                        Console.WriteLine();
                    }
                    Console.WriteLine("Your triangle is done!");
                }
            }
        }
    }
}
