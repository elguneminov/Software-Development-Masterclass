﻿using SchoolDomain;
using SchoolService;
using System;
using System.Collections.Generic;

namespace SchoolApp
{
    class Program
    {
        static List<Guid> instructorIds;
        static int maxInstructors = 1200;
        static List<Guid> courseIds;
        static int maxCourses = 5000;
        static List<Guid> studentIds;
        static int maxStudents = 100000;

        static void Main(string[] args)
        {
            var service = new Service();
            CreateLotsOfData();

            service.Controller("addstudenttocourse", new string[] { studentIds[100].ToString(), courseIds[12].ToString() });

            service.Controller("PersistData", new string[] { });

            service.Controller("LoadData", new string[] { });

        }

        static void CreateLotsOfData()
        {
            instructorIds = new List<Guid>();
            courseIds = new List<Guid>();
            studentIds = new List<Guid>();

            var service = new Service();

            for (var i = 1; i <= maxInstructors; i++)
            {
                var id = (Guid)service.Controller("CreateInstructor", new string[] { $"Test Instructor{i}" });
                instructorIds.Add(id);
            }
            for (var i = 1; i <= maxCourses; i++)
            {
                var id = (Guid)service.Controller("CreateCourse", new string[] { $"Course{i}", "3" });
                courseIds.Add(id);
            }
            for (var i = 1; i <= maxStudents; i++)
            {
                var id = (Guid)service.Controller("CreateStudent", new string[] { $"Test Student{i}", "0" });
                studentIds.Add(id);
            }
        }

        static void ShowStudentInfo(Student student)
        {
            if (student == null) Console.WriteLine("Student not found");
            else
            {
                Console.WriteLine($"Student Id: {student.Id}");
                Console.WriteLine($"Student Name: {student.Name}");
                Console.WriteLine($"Student GPA: {student.Gpa}");
            }

            try
            {
                Console.WriteLine($"Finished with {student.Name}");
            }
            catch (ArgumentException nullRefEx)
            {
                Console.WriteLine($"No Student found.");
            }
            catch (Exception excep)
            {
                Console.WriteLine($"Some exception was found.");
            }
            finally
            {
                Console.WriteLine("Closing everything down.");
            }
        }
    }
}
