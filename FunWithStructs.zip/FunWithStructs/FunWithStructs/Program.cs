﻿using System;

namespace FunWithStructs
{
    class Program
    {
        static void Main(string[] args)
        {
            var theClass = new MyClass();
            theClass.Name = "Mike";
            MyClass theClass2 = theClass;
            theClass2.Name = "Fred";

            var theStruct = new MyStruct();
            theStruct.Name = "Mary";
            MyStruct theStruct2 = theStruct;
            theStruct2.Name = "Sally";
        }
    }

    public class MyClass
    {
        public string Name { get; set; }

        public void myMethod(string name)
        {
            Name = name;
        }
    }

    public struct MyStruct
    {
        public string Name { get; set; }

        public void myMethod(string name)
        {
            Name = name;
        }
    }




}
