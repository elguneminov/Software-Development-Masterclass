﻿using SchoolData;
using SchoolDomain;
using System;

namespace SchoolBusiness
{
    public class Business
    {
        public void AddStudent(int id, string name, float gpa)
        {
            var data = new Data();
            var student = new Student
            {
                Id = id,
                Name = name,
                Gpa = gpa
            };
            data.CreateStudent(student);
        }
        public void AddInstructor(int id, string name)
        {
            var data = new Data();
            var instructor = new Instructor
            {
                Id = id,
                Name = name
            };
            data.CreateInstructor(instructor);
        }
        public void AddCourse(int id, string courseName, int creditHours)
        {
            var data = new Data();
            var course = new Course
            {
                Id = id,
                CourseName = courseName,
                CreditHours = creditHours
            };
            data.SaveCourse(course);
        }

        public void AddStudentToCourse(int studentId, int courseId)
        {
            var data = new Data();
            var studentCourse = new StudentCourse
            {
                Student = data.GetStudentById(studentId),
                Course = data.GetCourseById(courseId)
            };
            data.SaveStudentCourse(studentCourse);
        }
        public void AddInstructorToCourse(int instructorId, int courseId)
        {
            var data = new Data();
            var course = data.GetCourseById(courseId);
            var instructor = data.GetInstructorById(instructorId);
            course.Instructor = instructor;
            course.IsDirty = true;
            data.SaveCourse(course);
        }
        public void AddStudentGrade(int studentId, int courseId, string grade)
        {
            var data = new Data();
            var studentCourse = data.GetStudentCourseById(studentId, courseId);
            studentCourse.Grade = grade;
            studentCourse.IsDirty = true;
            data.SaveStudentCourse(studentCourse);
        }

        public Student GetStudent(int studentId)
        {
            var data = new Data();
            return data.GetStudentById(studentId);
        }
    }
}
