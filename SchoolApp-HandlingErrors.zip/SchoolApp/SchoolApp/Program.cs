﻿using SchoolDomain;
using SchoolService;
using System;

namespace SchoolApp
{
    class Program
    {
        static void Main(string[] args)
        {
            var service = new Service();
            service.Controller("CreateStudent", new string[] { "1", "Bob Smith", "0" });
            service.Controller("CreateInstructor", new string[] { "1", "Prof. Martin" });
            service.Controller("CreateCourse", new string[] { "1", "Algebra", "3" });
            service.Controller("AddStudentToCourse", new string[] { "1", "1" });
            service.Controller("AddInstructorToCourse", new string[] { "1", "1" });
            service.Controller("AddStudentGrade", new string[] { "1", "1", "A" });

            Student student = null;
            Student student2 = null;
            try
            {
                student = (Student)service.Controller("GetStudent", new string[] { "1" });
                ShowStudentInfo(student);
                student2 = (Student)service.Controller("GetStudent", new string[] { "2" });
                ShowStudentInfo(student2);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                student = null;
                student2 = null;
            }
        }

        static void ShowStudentInfo(Student student)
        {
            if (student == null) Console.WriteLine("Student not found");
            else
            {
                Console.WriteLine($"Student Id: {student.Id}");
                Console.WriteLine($"Student Name: {student.Name}");
                Console.WriteLine($"Student GPA: {student.Gpa}");
            }

            try
            {
                Console.WriteLine($"Finished with {student.Name}");
            }
            catch (ArgumentException nullRefEx)
            {
                Console.WriteLine($"No Student found.");
            }
            catch (Exception excep)
            {
                Console.WriteLine($"Some exception was found.");
            }
            finally
            {
                Console.WriteLine("Closing everything down.");
            }
        }
    }
}
