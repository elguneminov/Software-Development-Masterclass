﻿using SchoolDomain;
using System;

namespace SchoolData
{
    public class Data
    {
        public void CreateStudent(Student student)
        {
            Student.Students.Add(student);
        }
        public void CreateInstructor(Instructor instructor)
        {
            Instructor.Instructors.Add(instructor);
        }
        public void SaveCourse(Course course)
        {
            if (course.IsDirty)
            {
                for (var i=0; i<Course.Courses.Count; i++)
                {
                    if (Course.Courses[i].Id == course.Id)
                    {
                        course.IsDirty = false;
                        Course.Courses[i] = course;
                        return;
                    }
                }
            }
            Course.Courses.Add(course);
        }
        public void SaveStudentCourse(StudentCourse studentCourse)
        {
            if (studentCourse.IsDirty)
            {
                for (var i = 0; i < StudentCourse.StudentCourses.Count; i++)
                {
                    if (StudentCourse.StudentCourses[i].Student.Id == studentCourse.Student.Id
                        && StudentCourse.StudentCourses[i].Course.Id == studentCourse.Course.Id)
                    {
                        studentCourse.IsDirty = false;
                        StudentCourse.StudentCourses[i] = studentCourse;
                        return;
                    }
                }
            }
            StudentCourse.StudentCourses.Add(studentCourse);
        }
        public Student GetStudentById(int id)
        {
            foreach (var student in Student.Students)
            {
                if (student.Id == id) return student;
            }

            throw new Exception($"This student ID {id} was not found.");
        }
        public Instructor GetInstructorById(int id)
        {
            foreach (var instructor in Instructor.Instructors)
            {
                if (instructor.Id == id) return instructor;
            }
            return null;
        }
        public Course GetCourseById(int id)
        {
            foreach (var course in Course.Courses)
            {
                if (course.Id == id) return course;
            }
            return null;
        }
        public StudentCourse GetStudentCourseById(int studentId, int courseId)
        {
            foreach (var studentCourse in StudentCourse.StudentCourses)
            {
                if (studentCourse.Student.Id == studentId 
                    && studentCourse.Course.Id == courseId) return studentCourse;
            }
            return null;
        }
    }
}
