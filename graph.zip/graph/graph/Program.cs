﻿using System;

namespace graph
{
    class Program
    {
        static void Main(string[] args)
        {
            // y = x^2;
            // 225 * x = 80
            // x = .3555;

            for (var i=-15; i <= 15; i++)
            {
                var y = i * i * .3555;
                for (var j = 0; j < y; j++)
                {
                    Console.Write(" ");
                }
                Console.WriteLine("*");
            }
        }
    }
}
