﻿using System;

namespace FunWithDates
{
    class Program
    {
        static void Main(string[] args)
        {
            var current = DateTime.Now;
            var utcTime = DateTime.UtcNow;
            Console.WriteLine($"Now: {current}, UTC: {utcTime}");
            var today = DateTime.Now.Date;
            today = today.AddHours(3);
            var diff = current - today;
            Console.WriteLine($"Today's Timespan is: {diff}");
            Console.WriteLine($"Now: {current.ToShortDateString()}, UTC: {utcTime.ToLongTimeString()}");
            Console.WriteLine($"Now: {current.Kind}, UTC: {utcTime.Kind}");

            var may4 = new DateTime(2020, 5, 4);
            var may4Diff = current - may4;
            Console.WriteLine($"May the fourth be with you: {may4}, it's been {may4Diff.Days} days.");
            Console.WriteLine($"May the fourth be with you: {may4.ToString("T")}, it's been {may4Diff.Days} days.");
            Console.WriteLine($"May the fourth be with you: {may4.ToString("MMMMdd")}, it's been {may4Diff.Days} days.");

            var dtOffset = DateTimeOffset.Now;
            Console.WriteLine($"Offset now is: {dtOffset}");

        }
    }
}
