﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SchoolDomain
{
    public class StudentCourse
    {
        public Student Student { get; set; }
        public Course Course { get; set; }
        public string Grade { get; set; }
        public bool IsDirty { get; set; } = false;
    }
}
