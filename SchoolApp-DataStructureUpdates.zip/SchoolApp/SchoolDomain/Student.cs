﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SchoolDomain
{
    public class Student
    {
        public Guid Id { get; set; }
        public string Name { get; set; }
        public float Gpa { get; set; }
    }
}
