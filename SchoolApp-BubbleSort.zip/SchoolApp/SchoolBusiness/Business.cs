﻿using LoggingService;
using SchoolData;
using SchoolDomain;
using System;
using System.Diagnostics;

namespace SchoolBusiness
{
    public class Business
    {
        public Guid AddStudent(string name, float gpa)
        {
            Logger.Info($"Creating student: {name}");

            var data = new Data();
            var student = new Student
            {
                Name = name,
                Gpa = gpa
            };
            return data.CreateStudent(student);
        }
        public Guid AddInstructor(string name)
        {
            var data = new Data();
            var instructor = new Instructor
            {
                Name = name
            };
            return data.CreateInstructor(instructor);
        }
        public Guid AddCourse(string courseName, int creditHours)
        {
            var data = new Data();
            var course = new Course
            {
                CourseName = courseName,
                CreditHours = creditHours
            };
            return data.SaveCourse(course);
        }

        public void AddStudentToCourse(Guid studentId, Guid courseId)
        {
            var data = new Data();
            var studentCourse = new StudentCourse
            {
                Student = data.GetStudentById(studentId),
                Course = data.GetCourseById(courseId)
            };
            data.SaveStudentCourse(studentCourse);
        }
        public void AddInstructorToCourse(Guid instructorId, Guid courseId)
        {
            var data = new Data();
            var course = data.GetCourseById(courseId);
            var instructor = data.GetInstructorById(instructorId);
            course.Instructor = instructor;
            course.IsDirty = true;
            data.SaveCourse(course);
        }
        public void AddStudentGrade(Guid studentId, Guid courseId, string grade)
        {
            var data = new Data();
            var studentCourse = data.GetStudentCourseById(studentId, courseId);
            studentCourse.Grade = grade;
            studentCourse.IsDirty = true;
            data.SaveStudentCourse(studentCourse);
        }

        public Student GetStudent(Guid studentId)
        {
            var data = new Data();
            return data.GetStudentById(studentId);
        }

        public Student[] SkipAndFetchStudent(int skip, int count)
        {
            var data = new Data();
            return data.SkipAndFetchStudent(skip, count);
        }

        public Instructor[] SkipAndFetchInstructor(int skip, int count)
        {
            var data = new Data();
            return data.SkipAndFetchInstructor(skip, count);
        }

        public Course[] SkipAndFetchCourse(int skip, int count)
        {
            var data = new Data();
            return data.SkipAndFetchCourse(skip, count);
        }

        public string PersistData()
        {
            var data = new Data();
            return data.PersistDataStore();
        }

        public string LoadData()
        {
            var data = new Data();
            return data.LoadData();
        }

        public void SortStudents()
        {
            var data = new Data();
            var students = data.GetAllStudents();
            Student temp = null;

            var sw = new Stopwatch();
            sw.Start();
            int iterationCount = 0;
            int switchCount = 0;
            bool switched = true;
            int iterationReducer = 1;

            for (var j = 0; j < students.Count - 1 && switched; j++)
            {
                iterationCount++;
                switched = false;
                for (var i = 0; i < students.Count - iterationReducer; i++)
                {
                    if (string.Compare(students[i].Name, students[i + 1].Name) > 0)
                    {
                        switched = true;
                        switchCount++;
                        temp = students[i];
                        students[i] = students[i + 1];
                        students[i + 1] = temp;
                    }
                }
                iterationReducer++;
            }

            sw.Stop();
            Logger.Info($"Sorting {students.Count} records took {sw.ElapsedMilliseconds / 1000} seconds, with {iterationCount} iterations and {switchCount} switches");
        }

    }
}
