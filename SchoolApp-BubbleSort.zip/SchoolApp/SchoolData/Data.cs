﻿using LoggingService;
using Newtonsoft.Json;
using SchoolDomain;
using System;
using System.Collections.Generic;
using System.IO;

namespace SchoolData
{
    public class Data
    {
        static School School = null;
        static Data()
        {
            School = new School();
            School.Students = new List<Student>();
            School.Instructors = new List<Instructor>();
            School.Courses = new List<Course>();
            School.StudentCourses = new List<StudentCourse>();
        }
        public Guid CreateStudent(Student student)
        {
            student.Id = Guid.NewGuid();
            School.Students.Add(student);
            return student.Id;
        }
        public Guid CreateInstructor(Instructor instructor)
        {
            instructor.Id = Guid.NewGuid();
            School.Instructors.Add(instructor);
            return instructor.Id;
        }
        public Guid SaveCourse(Course course)
        {
            if (course.IsDirty)
            {
                for (var i=0; i< School.Courses.Count; i++)
                {
                    if (School.Courses[i].Id == course.Id)
                    {
                        course.IsDirty = false;
                        School.Courses[i] = course;
                        return course.Id;
                    }
                }
            }
            course.Id = Guid.NewGuid();
            School.Courses.Add(course);
            return course.Id;
        }
        public void SaveStudentCourse(StudentCourse studentCourse)
        {
            if (studentCourse.IsDirty)
            {
                for (var i = 0; i < School.StudentCourses.Count; i++)
                {
                    if (School.StudentCourses[i].Student.Id == studentCourse.Student.Id
                        && School.StudentCourses[i].Course.Id == studentCourse.Course.Id)
                    {
                        studentCourse.IsDirty = false;
                        School.StudentCourses[i] = studentCourse;
                        return;
                    }
                }
            }
            School.StudentCourses.Add(studentCourse);
        }
        public Student GetStudentById(Guid id)
        {
            foreach (var student in School.Students)
            {
                if (student.Id == id) return student;
            }

            throw new Exception($"This student ID {id} was not found.");
        }
        public Instructor GetInstructorById(Guid id)
        {
            foreach (var instructor in School.Instructors)
            {
                if (instructor.Id == id) return instructor;
            }
            return null;
        }
        public Course GetCourseById(Guid id)
        {
            foreach (var course in School.Courses)
            {
                if (course.Id == id) return course;
            }
            return null;
        }
        public StudentCourse GetStudentCourseById(Guid studentId, Guid courseId)
        {
            foreach (var studentCourse in School.StudentCourses)
            {
                if (studentCourse.Student.Id == studentId 
                    && studentCourse.Course.Id == courseId) return studentCourse;
            }
            return null;
        }

        public Student[] SkipAndFetchStudent(int skip, int count)
        {
            Student[] students = new Student[count];
            for (var i = skip; i < skip + count; i++)
            {
                students[i - skip] = School.Students[i];
            }
            return students;
        }

        public Instructor[] SkipAndFetchInstructor(int skip, int count)
        {
            Instructor[] instructors = new Instructor[count];
            for (var i = skip; i < skip + count; i++)
            {
                instructors[i - skip] = School.Instructors[i];
            }
            return instructors;
        }

        public Course[] SkipAndFetchCourse(int skip, int count)
        {
            Course[] courses = new Course[count];
            for (var i = skip; i < skip + count; i++)
            {
                courses[i - skip] = School.Courses[i];
            }
            return courses;
        }
        
        public List<Student> GetAllStudents()
        {
            return School.Students;
        }

        public string PersistDataStore()
        {
            var schoolJson = JsonConvert.SerializeObject(School);
            using (var sw = new StreamWriter(@"c:\temp\PersistedData\School-Data.txt"))
            {
                sw.WriteLine(schoolJson);
            }
            var persistInfo = $"Persisted {schoolJson.Length} bytes.";
            Logger.Info(persistInfo);
            return persistInfo;
        }

        public string LoadData()
        {
            string schoolJson = string.Empty;
            using (var sr = new StreamReader(@"c:\temp\PersistedData\School-Data.txt"))
            {
                schoolJson = sr.ReadLine();
            }
            School = (School)JsonConvert.DeserializeObject(schoolJson, typeof(School));
            var loadInfo = $@"Loaded:
Students: {School.Students.Count}
Courses: {School.Courses.Count}
Instructors: {School.Instructors.Count}
Student Courses: {School.StudentCourses.Count}";
            Logger.Info(loadInfo);
            return loadInfo;
        }

    }
}
