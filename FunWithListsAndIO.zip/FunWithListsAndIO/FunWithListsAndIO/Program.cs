﻿using System;
using System.Collections.Generic;
using System.IO;

namespace FunWithListsAndIO
{
    class Program
    {
        static void Main(string[] args)
        {
            var myList = new List<MyClass>();
            var c1 = new MyClass();
            c1.Name = "Mike";
            var c2 = new MyClass();
            c2.Name = "Bob";

            myList.Add(c1);
            myList.Add(c2);
            var c3 = myList[0];
            c3.Name = "Fred";

            using (var sw = new StreamWriter(@"C:\Temp\Intermediate\TestFolder\myfile.txt"))
            {
                sw.WriteLine("Some data");
                sw.WriteLine("Some data1");
                sw.WriteLine("Some data2");
                sw.WriteLine("Some data3");
                sw.WriteLine("Some data4");
            }

            using (var sr = new StreamReader(@"C:\Temp\Intermediate\TestFolder\myfile.txt"))
            {
                string line = string.Empty;
                while ((line = sr.ReadLine()) != null)
                {
                    Console.WriteLine(line);
                }
            }
        }
    }

    public class MyClass
    {
        public string Name { get; set; }
    }
}
