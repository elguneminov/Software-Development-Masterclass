﻿using System;

namespace FunWithClassesAndObjects
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");

            if (LightBulb.CheckBulbWattageLimits(25))
            {
                var theBulb = new LightBulb(25);
                theBulb.BulbType = "Flood";
                theBulb.TurnedOn = false;
                theBulb.Watts = 40;

                Console.WriteLine($"The bulb is turned? {theBulb.TurnedOn}");

                theBulb.Run(20);
                theBulb.TurnedOn = true;
                theBulb.Run(10);
                theBulb.Run(10);
                theBulb.Run(10);
                theBulb.Run(10);
                theBulb.Run(10);
                theBulb.Run(10);
            }
            else
            {
                Console.WriteLine("Too many watts");
            }

            var bulb2 = new LightBulb(40, "Flood", "My Favorite Bulb");
            bulb2.TurnedOn = true;
            bulb2.Run(20);
            bulb2.Run(20, true);

        }
    }

    public class LightBulb
    {
        private static readonly int lowerWattLimit = 10;
        private static readonly int upperWattLimit = 200;

        public static bool CheckBulbWattageLimits(int watts)
        {
            // !(watts < 10 || watts > 200) ==> (watts >= 10 && watts <= 200)
            return (watts >= 10 && watts <= 200);
        }
        private LightBulb() { }
        public LightBulb(int watts)
        {
            Watts = watts;
            TurnedOn = false;
            BurnedOut = false;
            BulbType = "General";
            name = "thebulb";
        }

        public LightBulb(int watts, string bulbType, string name)
        {
            Watts = watts;
            TurnedOn = false;
            BurnedOut = false;
            BulbType = bulbType;
            this.name = name;
        }
        private string name;
        private int hours = 0;
        private int maxHours = 50;
        public int Watts { get; set; }
        public bool TurnedOn { get; set; }
        public bool BurnedOut { get; private set; } = false;
        public string BulbType { get; set; }

        public void Run(int hours)
        {
            if (this.TurnedOn)
            {
                this.hours += hours;
                if (!BurnedOut && this.hours > maxHours)
                {
                    BurnOut();
                }
            }
        }
        public void Run(int hours, bool excessHeat)
        {
            if (this.TurnedOn)
            {
                if (excessHeat) this.hours += hours * 2;
                else this.hours += hours;
                if (!BurnedOut && this.hours > maxHours)
                {
                    BurnOut();
                }
            }
        }

        private void BurnOut()
        {
            this.BurnedOut = true;
            Console.WriteLine($"{name} is burned out!");
        }
    }
}
