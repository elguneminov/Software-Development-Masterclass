﻿using System;

namespace StringAndIntVariables
{
    class Program
    {
        static void Main(string[] args)
        {
            string str1;
            string str2;
            char ch1, ch2, ch3, ch4;
            int i1, i2, i3;

            bool b1 = true;
            bool b2 = false;

            Console.Write("Enter the first half of your sentence: ");
            str1 = Console.ReadLine();
            Console.Write("Enter the second half of your sentence: ");
            str2 = Console.ReadLine();

            Console.WriteLine($"Here's your sentence: {str1 + str2}");

            Console.Write("Enter the 4 chars: ");
            ch1 = Convert.ToChar(Console.Read());
            ch2 = Convert.ToChar(Console.Read());
            ch3 = Convert.ToChar(Console.Read());
            ch4 = Convert.ToChar(Console.Read());
            Console.ReadLine();

            Console.WriteLine($"Here's your word: {ch4.ToString() + ch3.ToString() + ch2.ToString() + ch1.ToString()}");

            Console.Write("Enter the first integer number: ");
            i1 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter the second integer number: ");
            i2 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter the third integer number: ");
            i3 = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine($"Here's the numbers added together: {i1 + i2 + i3}");
            Console.WriteLine($"Here's the numbers subtracted together: {i1 - i2 - i3}");
            Console.WriteLine($"Here's the numbers multiplied together: {i1 * i2 * i3}");
            Console.WriteLine($"Here's the numbers divided together: {i1 / i2 / i3}");

            Console.WriteLine($"Here's the AND result: {b1 && b2}");
            Console.WriteLine($"Here's the OR result: {b1 || b2}");
            Console.WriteLine($"Here's the NOT result !b1: {!b1}, !b2: {!b2}");

            Console.WriteLine($"{i1} < {i2} = {i1 < i2}");
            Console.WriteLine($"{i1} <= {i2} = {i1 <= i2}");
            Console.WriteLine($"{i1} > {i2} = {i1 > i2}");
            Console.WriteLine($"{i1} >= {i2} = {i1 >= i2}");
            Console.WriteLine($"{i1} == {i2} = {i1 == i2}");
            Console.WriteLine($"{i1} != {i2} = {i1 != i2}");
        }
    }
}
