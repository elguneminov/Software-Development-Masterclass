﻿using System;

namespace FunWithClassesAndObjects
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");

            var theBulb = new LightBulb();
            theBulb.BulbType = "Flood";
            theBulb.TurnedOn = false;
            theBulb.Watts = 40;

            Console.WriteLine($"The bulb is turned? {theBulb.TurnedOn}");

            theBulb.Run(20);
            theBulb.TurnedOn = true;
            theBulb.Run(10);
            theBulb.Run(10);
            theBulb.Run(10);
            theBulb.Run(10);
            theBulb.Run(10);
            theBulb.Run(10);
        }
    }

    public class LightBulb
    {
        public LightBulb()
        {
            Watts = 25;
            TurnedOn = false;
            BurnedOut = false;
            BulbType = "General";
            name = "thebulb";
        }

        private string name;
        private int hours = 0;
        private int maxHours = 50;
        public int Watts { get; set; }
        public bool TurnedOn { get; set; }
        public bool BurnedOut { get; private set; } = false;
        public string BulbType { get; set; }

        public void Run(int hours)
        {
            if (this.TurnedOn)
            {
                this.hours += hours;
                if (!BurnedOut && this.hours > maxHours)
                {
                    this.BurnedOut = true;
                    Console.WriteLine($"{name} is burned out!");
                }
            }
        }
    }
}
