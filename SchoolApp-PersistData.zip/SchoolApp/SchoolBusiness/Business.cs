﻿using SchoolData;
using SchoolDomain;
using System;
using System.Runtime.ExceptionServices;

namespace SchoolBusiness
{
    public class Business
    {
        public Guid AddStudent(string name, float gpa)
        {
            var data = new Data();
            var student = new Student
            {
                Name = name,
                Gpa = gpa
            };
            return data.CreateStudent(student);
        }
        public Guid AddInstructor(string name)
        {
            var data = new Data();
            var instructor = new Instructor
            {
                Name = name
            };
            return data.CreateInstructor(instructor);
        }
        public Guid AddCourse(string courseName, int creditHours)
        {
            var data = new Data();
            var course = new Course
            {
                CourseName = courseName,
                CreditHours = creditHours
            };
            return data.SaveCourse(course);
        }

        public void AddStudentToCourse(Guid studentId, Guid courseId)
        {
            var data = new Data();
            var studentCourse = new StudentCourse
            {
                Student = data.GetStudentById(studentId),
                Course = data.GetCourseById(courseId)
            };
            data.SaveStudentCourse(studentCourse);
        }
        public void AddInstructorToCourse(Guid instructorId, Guid courseId)
        {
            var data = new Data();
            var course = data.GetCourseById(courseId);
            var instructor = data.GetInstructorById(instructorId);
            course.Instructor = instructor;
            course.IsDirty = true;
            data.SaveCourse(course);
        }
        public void AddStudentGrade(Guid studentId, Guid courseId, string grade)
        {
            var data = new Data();
            var studentCourse = data.GetStudentCourseById(studentId, courseId);
            studentCourse.Grade = grade;
            studentCourse.IsDirty = true;
            data.SaveStudentCourse(studentCourse);
        }

        public Student GetStudent(Guid studentId)
        {
            var data = new Data();
            return data.GetStudentById(studentId);
        }

        public void PersistData()
        {
            var data = new Data();
            data.PersistDataStore();
        }

        public void LoadData()
        {
            var data = new Data();
            data.LoadData();
        }

    }
}
