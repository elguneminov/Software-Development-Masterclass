﻿using System;

namespace UserInteraction
{
    class Program
    {
        static void Main(string[] args)
        {
            string name;
            string color;

            Console.Write("Enter your name: ");
            name = Console.ReadLine();
            Console.Write($"Enter your favorite color {name}: ");
            color = Console.ReadLine();
            Console.WriteLine($"Hello {name}, {color} is my favorite color too!");
        }
    }
}
