﻿using System;

namespace MoreLogicFlows
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] array = { 1, 2, 3, 4, 5, 6, 7, 8, 9 };
            int[] array2 = { 2, 4 };

            foreach(var value in array)
            {
                switch (value)
                {
                    case 1:
                        Console.WriteLine("Found 1");
                        break;
                    case 2:
                    case 3:
                    case 4:
                        Console.WriteLine($"Found 2, 3, or 4: {value}");
                        break;
                    default:
                        Console.WriteLine($"Found something else: {value}");
                        break;
                }
            }

            Console.WriteLine("======================");
            foreach (var value2 in array2)
            {
                foreach (var value in array)
                {
                    if (!(value2 < value || value == value2))
                    {
                        Console.WriteLine($"Condition is met, value: {value}, value2: {value2}");
                    }
                }
            }
            Console.WriteLine("======================");
            foreach (var value2 in array2)
            {
                foreach (var value in array)
                {
                    if (value2 >= value && value != value2)
                    {
                        Console.WriteLine($"Condition is met, value: {value}, value2: {value2}");
                    }
                }
            }
        }
    }
}
