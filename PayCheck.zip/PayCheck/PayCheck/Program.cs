﻿using System;

namespace PayCheck
{
    class Program
    {
        static void Main(string[] args)
        {
            double hoursWorked = 0;
            double payRate = 15;
            bool isHourly = false;

            Console.Write("How many hours did you work this week? ");
            if (double.TryParse(Console.ReadLine(), out hoursWorked))
            {
                Console.Write("Are you an hourly employee? ");
                var answer = Console.ReadLine();

                if (answer == "Y" || answer == "y" || answer == "Yes" || answer == "YES")
                {
                    isHourly = true;
                }

                if (hoursWorked > 0)
                {
                    // More than 0 hours worked, calculate paycheck.
                    if (hoursWorked > 40 && isHourly)
                    {
                        // Calculate overtime pay
                        double payAmount = 40 * payRate + (hoursWorked - 40) * payRate * 1.5;
                        Console.WriteLine($"You received ${payAmount} in overtime pay.");
                    }
                    else
                    {
                        // Calculate straight time pay
                        double payAmount = hoursWorked * payRate;
                        Console.WriteLine($"You received ${payAmount} in straight time pay.");
                    }
                }
                else
                {
                    // No hours worked, terminating program
                    Console.WriteLine("You worked 0 hours this week so no paycheck.");
                }
            }
            else
            {
                // Bad data
                Console.WriteLine("You have to enter a number for the hours, try again.");
            }
        }
    }
}
