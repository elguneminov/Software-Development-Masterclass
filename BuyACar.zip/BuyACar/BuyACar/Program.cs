﻿using System;

namespace BuyACar
{
    class Program
    {
        static void Main(string[] args)
        {
            string color = string.Empty;
            string interiorColor = string.Empty;
            string transmission = string.Empty;
            string transmissionType = string.Empty;
            bool autoTransmission = false;
            string audioSystem = string.Empty;

            Console.WriteLine("We've got a great car for you!");
            Console.Write("What color would you like?");
            color = Console.ReadLine();
            if (color != "black" && color != "red" && color != "blue")
            {
                Console.WriteLine($"Well {color} is not available, so I'm going to give you black.");
                color = "black";
            }

            if (color == "black")
            {
                Console.Write("Would you like a white or grey interior? ");
                interiorColor = Console.ReadLine();
                if (interiorColor != "white" && interiorColor != "grey")
                {
                    Console.WriteLine($"Well {interiorColor} is not available, so I'm going to give you grey.");
                    interiorColor = "grey";
                }
            }
            else if (color == "red")
            {
                Console.Write("Would you like a white or black interior? ");
                interiorColor = Console.ReadLine();
                if (interiorColor != "white" && interiorColor != "black")
                {
                    Console.WriteLine($"Well {interiorColor} is not available, so I'm going to give you black.");
                    interiorColor = "black";
                }
            }
            else if (color == "blue")
            {
                Console.WriteLine("Blue comes with a grey interior.");
                interiorColor = "grey";
            }

            Console.Write("You can have a 4 or 6 speed transmission, which would you like? (4 or 6) ");
            transmission = Console.ReadLine();
            if (transmission != "4" && transmission != "6")
            {
                Console.WriteLine($"Well a {transmission} speed transmission is not available, so I'm going to give you 4 speed.");
                transmission = "4";
            }

            if (transmission == "4")
            {
                Console.Write("You can have an automatic or manual transmission, which would you like? (automatic/manual) ");
                transmissionType = Console.ReadLine();
                if (transmissionType != "automatic" && transmissionType != "manual")
                {
                    Console.WriteLine($"Well a {transmissionType} type transmission is not available, so I'm going to give you automatic.");
                    autoTransmission = true;
                }
                else
                {
                    autoTransmission = transmissionType == "automatic";
                }
            }
            else
            {
                Console.WriteLine("A 6 speed transmission gets an automatic transmission.");
                autoTransmission = true;
            }

            Console.WriteLine("Congratulations on your new car:");
            Console.WriteLine($"Color: {color}, Interior: {interiorColor}");
            Console.WriteLine($"Transmission: {transmission}-speed, Auto: {autoTransmission}");
        }
    }
}
