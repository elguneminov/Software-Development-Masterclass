﻿using System;

namespace FunWithStrings
{
    class Program
    {
        static void Main(string[] args)
        {
            string s1 = "Hello World";
            string s2 = s1.Substring(1, 2);
            Console.WriteLine($"s1: {s1}, s2: {s2}");

            var s3 = s2;
            Console.WriteLine($"s3: {s3}, s2: {s2}");
            Console.WriteLine($"s1: {s1.Length}, s2: {s2.Length}");

            Console.WriteLine($"s1: {s1.ToUpper()}");
            Console.WriteLine($"s1: {s1[0]} {s1[1]} {s1[2]} {s1[3]} {s1[4]} ");

            Console.WriteLine(@"
Hello this is my
paragraph
that I want to write
out.
");



        }
    }
}
