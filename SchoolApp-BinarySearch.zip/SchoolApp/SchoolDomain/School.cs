﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SchoolDomain
{
    public class School
    {
        public List<Student> Students { get; set; }
        public bool StudentsSorted { get; set; } = false;
        public List<Instructor> Instructors { get; set; }
        public List<Course> Courses { get; set; }
        public List<StudentCourse> StudentCourses { get; set; }
    }
}
