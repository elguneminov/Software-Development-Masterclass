﻿using System;

namespace Methods
{
    class Program
    {
        static void ShowGreeting()
        {
            var greeting = "Welcome to our restaurant, how can I help you?";
            Console.WriteLine(greeting);
        }

        static void PresentMenu(string menu)
        {
            Console.WriteLine(menu);
        }

        static void GetOrder()
        {
            var orderPrompt = "What would you like to order? ";
            var orderAcknowledge = "Your order will be ready at the counter, thank you.";
            Console.Write(orderPrompt);
            var order = Console.ReadLine();
            Console.WriteLine(orderAcknowledge);
        }

        static double GetPayment()
        {
            var paymentPrompt = "Please pay for your order: ";
            var paymentAcknowledge = "Thank you for your payment";
            Console.Write(paymentPrompt);
            var payment = Console.ReadLine();
            Console.WriteLine(paymentAcknowledge);

            return Convert.ToDouble(payment);
        }
        static void Main(string[] args)
        {
            double totalAmount = 0;
            var breakfastMenu = "Here is our menu: Pancakes, coffee, eggs, oatmeal";
            var lunchMenu = "Here is our menu: Sandwich, coffee, pie, pot roast";

            while (true)
            {
                ShowGreeting();

                var menu = string.Empty;

                if (DateTime.Now.Hour < 15) menu = breakfastMenu;
                else menu = lunchMenu;

                PresentMenu(menu);
                GetOrder();
                totalAmount += GetPayment();

                Console.WriteLine($"We've collected ${totalAmount} today!!!");
            }
        }
    }
}
