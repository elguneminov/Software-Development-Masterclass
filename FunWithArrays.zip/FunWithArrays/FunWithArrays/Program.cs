﻿using System;

namespace FunWithArrays
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] strings = { "abc", "def", "efg", "hij", "klm", "nop", "qrs", "tuv", "wxyz" };
            for (var i=0; i < strings.Length; i++)
            {
                Console.WriteLine($"Row {i + 1}: {strings[i]}");
            }

            for (var i=strings.Length-1; i >= 0; i--)
            {
                Console.WriteLine($"Row {i + 1}: {strings[i]}");
            }

            string[,] solid = {
                { "*", "*", "*", "*", "*" },
                { "*", "*", "*", "*", "*" },
                { "*", "*", "*", "*", "*" },
                { "*", "*", "*", "*", "*" },
                { "*", "*", "*", "*", "*" }
            };

            string[,] theX = {
                { "*", " ", " ", " ", "*" },
                { " ", "*", " ", "*", " " },
                { " ", " ", "*", " ", " " },
                { " ", "*", " ", "*", " " },
                { "*", " ", " ", " ", "*" }
            };

            for (var i = 0; i < solid.GetLength(0); i++)
            {
                for (var j = 0; j < solid.GetLength(1); j++)
                {
                    Console.Write(solid[i, j]);
                }
                Console.WriteLine();
            }

            for (var i = 0; i < theX.GetLength(0); i++)
            {
                for (var j = 0; j < theX.GetLength(1); j++)
                {
                    Console.Write(theX[i, j]);
                }
                Console.WriteLine();
            }

            string[,] result = new string[5, 5];
            for (var i = 0; i < theX.GetLength(0); i++)
            {
                for (var j = 0; j < theX.GetLength(1); j++)
                {
                    if (solid[i, j] != theX[i, j]) result[i, j] = "*";
                    else result[i, j] = " ";
                }
            }

            for (var i = 0; i < result.GetLength(0); i++)
            {
                for (var j = 0; j < result.GetLength(1); j++)
                {
                    Console.Write(result[i, j]);
                }
                Console.WriteLine();
            }
        }
    }
}
