﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SchoolDomain
{
    public class Course
    {
        public Guid Id { get; set; }
        public string CourseName { get; set; }
        public int CreditHours { get; set; }
        public Instructor Instructor { get; set; }
        public bool IsDirty { get; set; } = false;
        public Course Left { get; set; } = null;
        public Course Right { get; set; } = null;
    }
}
