﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SchoolDomain
{
    public class School
    {
        public List<Student> Students { get; set; }
        public bool StudentsSorted { get; set; } = false;
        public SortedDictionary<string, Instructor> Instructors { get; set; }
        public Course Courses { get; set; } = null;
        public List<StudentCourse> StudentCourses { get; set; }
    }
}
