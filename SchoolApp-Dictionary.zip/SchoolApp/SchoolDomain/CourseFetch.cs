﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SchoolDomain
{
    public class CourseFetch
    {
        public List<Course> Courses { get; set; }
        public int SkipCount { get; set; } = 0;
        public int FetchCount { get; set; } = 0;
        public int SkipRequest { get; set; }
        public int FetchRequest { get; set; }
        public int CheckCount { get; set; } = 0;
        public int LeftCount { get; set; } = 0;
        public int RightCount { get; set; } = 0;
    }
}
